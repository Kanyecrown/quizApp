//For SCREENS...
const startScreen =
 document.querySelector('.start-screen');
 
 const restartBtn =
  document.querySelector('.restart');

const quiz = document.querySelector('.quiz');

const endScreen =
 document.querySelector('.end-screen');

//The VALUES
const numQuestions =
 document.querySelector('#num-questions');

const category =
 document.querySelector('#category');

const difficulty =
 document.querySelector('#difficulty');

const timePerquestion =
 document.querySelector('#time');

//PROGRESS BAR.....
const progressFill =
 document.querySelector('.progress-bar');

const progressTest =
 document.querySelector('.progress-text');

//.....Question
const questionText =
 document.querySelector('.question');

const current =
 document.querySelector('.current');

const total =
 document.querySelector('.total');



//.....Buttons...
const submitBtn =
 document.querySelector('.submit');

const nextBtn =
 document.querySelector('.next');

const startBtn =
 document.querySelector('.start-quiz')

//LETssss....
let questions = [];
let score = 0;
let questionNo = 0;
let questionIndex = 0;
let timer;
let time = 20;
let availableQuestion = [];

progress = (value) => {
 let percentage = value / time * 100
 progressFill.style.width = `${percentage}%`;
 progressTest.textContent = value;
}

let MAX_QUESTION = 0;

const startQuiz = () => {
 loadingAnimation();
 const num = numQuestions.value,
  cat = category.value,
  diff = difficulty.value
 MAX_QUESTION = num;
 const url = `https://opentdb.com/api.php?amount=${num}&category=${cat}&difficulty=${diff}&type=multiple`;
 fetch(url).then((res) => res.json())
  .then(data => {
   questions = data.results

   startScreen.classList.add('hide');
   quiz.classList.remove('hide');
   showQuestion()
  })
}
startBtn.addEventListener('click', startQuiz);



function showQuestion() {
 /*using the spread operator to copy the array into Available question*/
 availableQuestion = [...questions];

 currentQuestion =
  availableQuestion[questionIndex];

questionText.innerHTML =
currentQuestion.question;

 questionNo = questionIndex + 1;

 const answerWrapper = document.querySelector('.answer-wrapper');
/*joining to array together using the toString()*/
 const answers = [...currentQuestion.incorrect_answers, currentQuestion.correct_answer.toString(),];

/* after joing the arrays 2geda the incorrect_answer will always be at the bottom so we use the sort() with math random to shuffle the array*/
 answers.sort(() => Math.random() - 0.5);
 
 /* looping through d array and displaying it on the page */
 answerWrapper.innerHTML = "";
 answers.forEach(answer => {
  answerWrapper.innerHTML += `
    <div class="answer ">
       <span class="text">${answer}</span>
       <span class="checkbox">
       <img class="checker" src="images/fa-check.jpeg">
       </span>
       </div>
   `
 });

current.textContent = questionNo;
 
 total.textContent = `/${availableQuestion.length}`;



 const answerDiv =
  document.querySelectorAll('.answer');
/* Adding an eventListener to the answer btn'S */
 answerDiv.forEach((answer) => {
  answer.addEventListener('click', () => {
   if (!answer.classList.contains("checked")) {
    answerDiv.forEach((answer) => {
     answer.classList.remove("selected")
    })
    answer.classList.add("selected")
    submitBtn.disabled = false;
   }
  });
 });

/* starting the time and displaying it with the progress Bar */
 time = timePerquestion.value;
 startTimer(time);
}
/* end of show Question  */

/* ...... */
startTimer = (time) => {
 timer = setInterval(() => {
  if (time >= 0) {
   progress(time);
   time--;
  } else {
   checkAnswer();
  }
 },1000);
}

submitBtn.addEventListener('click', () => {
 checkAnswer();
})

checkAnswer = () => {
/* the clearInterval stops the countDown */
 clearInterval(timer);

 const selectedAnswer =
  document.querySelector('.answer.selected');
/* if user click on the botton */
/* if the user click the right answer it highlights the border */
 if (selectedAnswer) {
  const answer = selectedAnswer.querySelector('.text').innerHTML;
  if (answer === currentQuestion.correct_answer) {
   score++;
   selectedAnswer.classList.add('correct')
  } else {
/* if answer is wrong its highlight indicating wrong */
   selectedAnswer.classList.add('wrong')

/*This highlight the right answer incase the user click on the wrong one*/
   const answerDiv = document.querySelectorAll('.answer')
   answerDiv.forEach(answer => {
    if (
     answer.querySelector('.text').innerHTML === currentQuestion.correct_answer) {
     answer.classList.add('correct')
    }
   });
  }
 }/*leaving the selected answer func*/ else {
  
  /* if the user did not click on any answer still highlight the right one */
  const correctAnswer = document.querySelectorAll('.answer')
  correctAnswer.forEach(answer => {
   if (
    answer.querySelector('.text').innerHTML === currentQuestion.correct_answer) {
    answer.classList.add('correct')
   }
  });
 }

 const answerDiv = document.querySelectorAll('.answer');
 /* after the click disabling the click function */
 answerDiv.forEach(answer => {
  answer.classList.add('checked')
 });
 
 submitBtn.style.display = 'none';
 nextBtn.style.display = 'block';
}

nextBtn.addEventListener('click', () => {
 nextBtn.style.display = 'none';
  submitBtn.style.display = 'block';
 getNextQuestion();
})

getNextQuestion = () => {
    questionIndex++;
 if (questionIndex < availableQuestion.length) {
  showQuestion();
 } else {
  showScore();
 }
}

showScore = () => {
 quiz.classList.add('hide');
 endScreen.classList.remove('hide')
 
 const finalScore = document.querySelector(".final-score");
 
 const totalScore = document.querySelector(".total-score");
 
 finalScore.textContent = score;
 totalScore.textContent = `/${availableQuestion.length}`
}

restartBtn.addEventListener('click',() => {
    return window.location.reload();
});

function loadingAnimation() {
 startBtn.innerHTML = "Loading";
 const loadInterval = setInterval(() => {
   if (startBtn.innerHTML.length === 10) {
       startBtn.innerHTML = "Loading"
   }else{
       startBtn.innerHTML += "."
   }
 },500)
}



