const questions = [
  {
question: "What is the scientific name of the knee cap?", 
  incorrect_answers:[
  "Foramen Magnum",  
    "scapula",
    "Femur"],
  correct_answer: "Patella"
},
 {
question: "Inside which HTML element do we put the JavaScript?",
incorrect_answers:[
"<javascript>", 
"<js>",
"<scripting>"],
correct_answer:  "<script>"
  },
  {
question: "Which of these Roman gods doesn&#039;t have a counterpart in Greek mythology?", 
correct_answer: "Janus",
 incorrect_answers:[
  "Vulcan",
  "Juno",
  "Mars"]
  },
  {
  question: "What was the release date of &quot;Grand Theft Auto IV&quot;?",
  correct_answer: "April 29, 2008",
  incorrect_answers:[
  "May 21, 2009",
  "June 22, 2010",
  "July 28, 2008"]
  },
  {
  question: "Which of the following games was NOT included in Valve&#039;s Orange Box?",
  correct_answer: "Counter-Strike"
  incorrect_answers:[
  "Portal",
  "Half-Life 2: Episode Two",
  "Tea,m Fortress 2"]
  },
  {
  question: "In Sid Meier&#039;s Civilization V, which World Wonder can only be built in cities on or next to a desert?",
  correct_answer: "Petra",
  correct_answer: "Petra"
  incorrect_answers:[
  "The Pyramids",
  "Alhambra",
  "Mausoleum of Maussollos"]
  },
  {
  question: "What is the French word for &quot;fish&quot;?",
  correct_answer: "poisson",
  incorrect_answers:[
  "fiche",
  "escargot",
  "mer"]
  },
  {
  question: "What is the French word for &quot;fish&quot;?", 
  correct_answer: "poisson"
  incorrect_answers:[
  "fiche"
  "escargot"
  "mer"]
  }
];





